Single Sided KiCAD ProMicro footprint with extra pin support for the Nice!Nano, and the common RP2040 and NRF Pro Micro clones on AliExpress.

![Footprint](https://github.com/Aleblazer/TheOneProMicro/blob/main/Images/TheOneProMicro.png?raw=true) ![Symbol](https://github.com/Aleblazer/TheOneProMicro/blob/main/Images/TheOneProMicroSym.png?raw=true)
